var mongo = require('mongodb');

var Server = mongo.Server,
    Db = mongo.Db,
    BSON = mongo.BSONPure;

var server = new Server('localhost', 27017, {auto_reconnect: true});
db = new Db('mydb', server);

db.open(function(err, db) {
    if(!err) {
        console.log("Connected to 'mydb' database");
        db.collection('mycollection', {strict:true}, function(err, collection) {
            if (err) {
                console.log("The 'wines' collection doesn't exist. Creating it with sample data...");
                populateDB();
            }
        });
    }
});
exports.findAll = function(req, res) {
    db.collection('mycollection', function(err, collection) {
        collection.find().toArray(function(err, items) {
            res.send(items);
        });
    });
};



exports.findById = function(req, res) {
    var MN = 'Ashish';
    console.log('Retrieving wine: ' + MN);
    db.collection('mycollection', function(err, collection) {
       u = collection.find({ManagerName:MN}).toArray(function(err, items) {
        idlist= []
        items.forEach(function(myDoc) { idlist.push(myDoc.EmpName )} )
        collection.aggregate([
        {$match:{ManagerName:{$in:idlist}}},
        {
        $group: {
            _id: "$ManagerName",
            'Greater_than_9': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$More_than_9", '' ] }, 1, 0]
                }
            },
           'Greater_than_12': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$More_than_12", '' ] }, 1, 0]
                }
            },
            
            'Less_than_6': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$Less_than_6", '' ] }, 1, 0]
                }
            }
        }
    }
    

        ]) .toArray(function(err, item){
        res.send(item)

        });
        });
    });
};

