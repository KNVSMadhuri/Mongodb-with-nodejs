var mongo = require('mongodb');

var Server = mongo.Server,
    Db = mongo.Db,
    BSON = mongo.BSONPure;

var server = new Server('localhost', 27017, {auto_reconnect: true});
db = new Db('mydb', server);

db.open(function(err, db) {
    if(!err) {
        console.log("Connected to 'mydb' database");
        db.collection('mycollection', {strict:true}, function(err, collection) {
            if (err) {
                console.log("The 'wines' collection doesn't exist. Creating it with sample data...");
                populateDB();
            }
        });
    }
});
exports.findAll = function(req, res) {
    db.collection('mycollection', function(err, collection) {
        collection.find().toArray(function(err, items) {
            res.send(items);
        });
    });
};



exports.findById = function(req, res) {
    var MN = req.params.MN;
    console.log('Retrieving wine: ' + MN);
    db.collection('mycollection', function(err, collection) {
        collection.find({'ManagerName':MN}).toArray(function(err, item) {
            res.send(item);
        });
    });
};

