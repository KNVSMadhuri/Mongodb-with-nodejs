
var myApp = angular.module('myApp', ['ngRoute','ngAnimate', 'ngSanitize', 'ui.bootstrap']);



myApp.config(function($routeProvider) {
	$routeProvider
		.when('/', {
			templateUrl: 'login.html',
			controller: 'loginCtrl'
		})
		.when('/home', {
			templateUrl: 'home.html',
			controller: 'AppCtrl'
		})
		.when('/employeelist', {
			templateUrl: 'employee.html',
			controller: 'AppCtrl'
		})
		.when('/viewManagers', {
			templateUrl: 'managers.html',
			controller: 'AppCtrl'
		})
		.otherwise({
			redirectTo: '/home'
		});
});



myApp.controller('AppCtrl', ['$scope', '$http','$location', function($scope, $http,$location) {
    //console.log("Hello World from controller");

    $http.get('/employeelist?MN='+$location.search().MN).success(function(response){
      //console.log("I got the data I requested");
      //console.log(response);
      $scope.employeelist = response;
 }); 

 $http.get('/managerslist?MN='+$location.search().MN).success(function(response){
      console.log("I got the data I requested:managerslist");
      console.log(response);
      $scope.managerslist = response;
 }); 



}]);

myApp.controller('loginCtrl', function($scope, $location){
	$scope.submit = function(){
		var uname = $scope.username;
		var password = $scope.password;
		console.log("clicked");
		console.log(uname);
		console.log(password);

		if($scope.username == 'Ashish' && $scope.password =='Ashish'){
			$location.path('/home');
			
		}
		else if($scope.username == 'Saloni' && $scope.password =='Saloni'){
			$location.path('/home');
		}
		else if($scope.username == 'Vishnu' && $scope.password =='Vishnu'){
			$location.path('/home');
		}
		else if($scope.username == 'Nivedita' && $scope.password =='Nivedita'){
			$location.path('/home');
		}
		else if($scope.username == 'Valli' && $scope.password =='Valli'){
			$location.path('/home');
		}
		else if($scope.username == 'Bhoomika' && $scope.password =='Bhoomika'){
			$location.path('/home');
		}
		else
		{
			alert("please enter valid credentials");
		}

	}; 
	

});


myApp.controller('DatepickerPopupDemoCtrl', function ($scope,$http) {
  $scope.today = function() {
    $scope.dt = new Date();
  };
  $scope.today();

  $scope.clear = function() {
    $scope.dt = null;
  };

  $scope.inlineOptions = {
    customClass: getDayClass,
    minDate: new Date(),
    showWeeks: true
  };

  $scope.dateOptions = {
    //dateDisabled: disabled,
    formatYear: 'yy',
    maxDate: new Date(2020, 5, 22),
    minDate: new Date(),
    startingDay: 1
  };

  // Disable weekend selection
  /*function disabled(data) {
    var date = data.date,
      mode = data.mode;
    return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
  }*/

  $scope.toggleMin = function() {
    $scope.inlineOptions.minDate = $scope.inlineOptions.minDate ? null : new Date();
    $scope.dateOptions.minDate = $scope.inlineOptions.minDate;
  };

  $scope.toggleMin();

  $scope.open1 = function() {
    $scope.popup1.opened = true;
    
  };

  $scope.open2 = function() {
    $scope.popup2.opened = true;
  };

  $scope.setDate = function(year, month, day) {
    $scope.frmdt = new Date(year, month, day);

  };

  $scope.formats = ['mm-dd-yy', 'shortDate'];
  $scope.format = $scope.formats[0];
  $scope.altInputFormats = ['M!/d!/yyyy'];

  $scope.popup1 = {
    opened: false
  };

  $scope.popup2 = {
    opened: false
  };

  var tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  var afterTomorrow = new Date();
  afterTomorrow.setDate(tomorrow.getDate() + 1);
  $scope.events = [
    {
      date: tomorrow,
      status: 'full'
    },
    {
      date: afterTomorrow,
      status: 'partially'
    }
  ];

  function getDayClass(data) {
    var date = data.date,
      mode = data.mode;
    if (mode === 'day') {
      var dayToCheck = new Date(date).setHours(0,0,0,0);

      for (var i = 0; i < $scope.events.length; i++) {
        var currentDay = new Date($scope.events[i].date).setHours(0,0,0,0);

        if (dayToCheck === currentDay) {
          return $scope.events[i].status;
        }
      }
    }

    return '';
  }
var data={};
  $scope.submit= function(){
      var frmdt = $('#frmdt').val();
     var  todt=$('#todt').val();
     
      dates={"frmdt":frmdt,"todt":todt};
      
       $http.post("/managerslist", dates).success(function(res, req) {
        console.log("After",dates);
        console.log(res);

        $('#daterangefilter').empty();
    
        $('#daterangefilter').empty();
        for(i=0;i<=res.length;i++){
          $('#daterangefilter').append('<tr>'+
                    '<td><a href="#/employeelist?MN='+res[i]['_id']+'">'+res[i]['_id']+'</a></td>'+
                    '<td>'+res[i]['Less_than_6']+'</td>'+
                    '<td>'+res[i]['Less_than_9']+'</td>'+
                    '<td>'+res[i]['More_than_9']+'</td>'+
                    '<td>'+res[i]['More_than_12']+'</td>'+
                    '<td>'+res[i]['Man_Days']+'</td>'+
                    '<td>'+res[i]['Holidays']+'</td></tr></tbody>');
  
        };
      });
     
};

});


