var mongo = require('mongodb');

var Server = mongo.Server,
    Db = mongo.Db,
    BSON = mongo.BSONPure;

var server = new Server('localhost', 27017, {auto_reconnect: true});
db = new Db('mydb', server);

db.open(function(err, db) {
    if(!err) {
        console.log("Connected to 'mydb' database");
        db.collection('mycollection', {strict:true}, function(err, collection) {
            if (err) {
                console.log("The 'wines' collection doesn't exist. Creating it with sample data...");
                populateDB();
            }
        });
    }
});
exports.findAll = function(req, res) {
    db.collection('mycollection', function(err, collection) {
        collection.find().toArray(function(err, items) {
            res.send(items);
        });
    });
};



exports.findById = function(req, res) {
    var MN = req.params.MN;
    console.log('Retrieving wine: ' + MN);
    db.collection('mycollection', function(err, collection) {
        collection.aggregate([
    {$match:{ManagerName:MN}},
    {
        $project: {
            Empid: 1,
            EmpName:1,
            More_than_9: {  
                $cond: [ { $ne: ["$More_than_9", '' ] }, 1, 0]
            },
            More_than_12: {  
                $cond: [ { $ne: [ "$More_than_12", '' ] }, 1, 0]
                
            },
           Less_than_6: {  
                $cond: [ { $ne: [ "$Less_than_6", '' ] }, 1, 0]
                
            }, 
        }
    },
    {
        $group: {
            _id: "$Empid",
            EmpName: { $first: "$EmpName" },
            Greater_than_9: { $sum: "$More_than_9" },
            Greater_than_12: { $sum: "$More_than_12" },
            Less_than_6:{$sum:"$Less_than_6"},
            
        }
    }
]).toArray(function(err, item) {
            res.send(item);
        });
    });
};

