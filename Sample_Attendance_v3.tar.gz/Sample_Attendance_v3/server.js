var express = require('express');

var app = express();

var mangojs = require('mongojs');
var db = mangojs('mydb');
var mycollection = db.collection('mycollection');
app.use(express.static(__dirname + '/public'));

var bodyParser = require('body-parser');

app.get('/employeelist', function (req, res){
	//console.log("I Recived a GET Request");
	var MN = req.query.MN;
mycollection.aggregate([
    {$match:{ManagerName:MN}},
    {
        $project: {
            Empid: 1,
            EmpName:1,
            ManagerName:1,
            More_than_9: {  
                $cond: [ { $ne: ["$More_than_9", '' ] }, 1, 0]
            },
            More_than_12: {  
                $cond: [ { $ne: [ "$More_than_12", '' ] }, 1, 0]
                
            },
           Less_than_6: {  
                $cond: [ { $ne: [ "$Less_than_6", '' ] }, 1, 0]
                
            }, 
            Less_than_9: {  
                $cond: [ { $ne: [ "$Less_than_9", '' ] }, 1, 0]
                
            },
        }
    },
    {
        $group: {
            _id: "$Empid",
            EmpName: { $first: "$EmpName" },
            ManagerName: { $first: "$ManagerName" },
            More_than_9: { $sum: "$More_than_9" },
            More_than_12: { $sum: "$More_than_12" },
            Less_than_6:{$sum:"$Less_than_6"},
            Less_than_9:{$sum:"$Less_than_9"}
            
        }
    }
]).toArray(function(err, item) {
            res.send(item);
        });
    
     
//res.json(results);


}); 




app.get('/managerslist', function (req, res){
	console.log("I Recived a GET Request");
    

var MN = req.query.MN;
    
    //console.log('Retrieving wine: ' + MN);
    
       mycollection.find({ManagerName:MN}).toArray(function(err, items) {
        idlist= [];
        items.forEach(function(myDoc) { idlist.push(myDoc.Empid );} );

        mycollection.aggregate([
        {$match:{Managerid:{$in:idlist}}},
        {
         $group: {
            _id: "$ManagerName",
            
            'More_than_9': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$More_than_9", '' ] }, 1, 0]
                }
            },
           'More_than_12': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$More_than_12", '' ] }, 1, 0]
                }
            },
            
            'Less_than_6': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$Less_than_6", '' ] }, 1, 0]
                }
            },

            'Less_than_9': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$Less_than_9", '' ] }, 1, 0]
                }
            }
        }
    }
    ]).toArray(function(err, item){ 
    console.log(item);  
        res.send(item);
        });
//console.log(u);
        });

});

app.use(bodyParser.json());
/*Angular to node date filter*/
app.post('/managerslist', function(req, res) {
  console.log("I recieved post request")

  var MN = 'Ashish';
   var fd = req.body.frmdt;
   var td = req.body.todt;
   console.log("FDates:" +fd) 
   console.log("TDates:"+td)
    mycollection.find({$and:[{ManagerName: MN },{Date:{$gte:fd,$lte:td}}]}).toArray(function(err, items) {
        idlist= [];
        items.forEach(function(myDoc) {idlist.push(myDoc.Empid),idlist.push(myDoc.Date)} );
        
        mycollection.aggregate([
        {$match:{$and:[{"Managerid": {$in : idlist}},{"Date":{$in:idlist}}]}},
        {
         $group: {
            _id: "$ManagerName",
            
            'More_than_9': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$More_than_9", '' ] }, 1, 0]
                }
            },
           'More_than_12': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$More_than_12", '' ] }, 1, 0]
                }
            },
            
            'Less_than_6': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$Less_than_6", '' ] }, 1, 0]
                }
            },

            'Less_than_9': { 
                '$sum': {
                    '$cond':  [ { $ne: ["$Less_than_9", '' ] }, 1, 0]
                }
            }
        }
    }

    ]).toArray(function(err, item){

    console.log("This is angular data");
    console.log(item);
    return res.send(item);




    

});
      
});

});

app.listen(3000);
console.log("server running on port 3000");


